﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class GradientScript : MonoBehaviour {

	public Material gradientMaterial; 

	void Start()
	{
		gradientMaterial.SetColor ("_Color", Color.black); //left color
		gradientMaterial.SetColor("_Color2", Color.white); 
	}

}
