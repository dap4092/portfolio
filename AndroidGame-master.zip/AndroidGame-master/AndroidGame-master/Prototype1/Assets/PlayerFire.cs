﻿using UnityEngine;

public class PlayerFire : MonoBehaviour
{
    public float fireStrength = 500;
    public Color nextColor = Color.red;
}