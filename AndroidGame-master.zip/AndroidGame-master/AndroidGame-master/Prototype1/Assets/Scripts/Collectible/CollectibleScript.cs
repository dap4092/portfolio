﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectibleScript : MonoBehaviour {

	float speed = 4.0f; 
	float fadeTime = 1.0f; 
	float flashInterval = 0.5f; 
	MeshRenderer rend; 

	// Use this for initialization
	void Start () {
		rend = GetComponent<MeshRenderer> (); 
		StartCoroutine (MakeInvisible ()); 
	}
	
	// Update is called once per frame
	void Update () {
		transform.Rotate (0, 0, speed);

//		if (!routineActive) {
//			if (!visible) {
//				StartCoroutine (MakeVisible ());
//			} else {
//				StartCoroutine (MakeInvisible ()); 
//			}
//		}
	}

	IEnumerator MakeVisible()
	{
		float elapsedTime = 0.0f;
		float startTime = Time.time; 

		Color color = new Color(rend.material.color.r, rend.material.color.g, rend.material.color.b, rend.material.color.a);

		while (color.a < 1)
		{
			elapsedTime += Time.time - startTime;
			color.a = Mathf.Clamp01((elapsedTime / fadeTime));
			rend.material.color = color;
			yield return null;
		}
        rend.material.color = color; 
		yield return new WaitForSeconds (flashInterval);
		StartCoroutine (MakeInvisible ()); 
		yield return null;

    }

	IEnumerator MakeInvisible()
	{ 
		float elapsedTime = 0.0f;
		float startTime = Time.time; 

		Color color = new Color(rend.material.color.r, rend.material.color.g, rend.material.color.b, rend.material.color.a);

		while (color.a > 0)
		{
			elapsedTime += Time.time - startTime;
			color.a = Mathf.Clamp01(1.0f - (elapsedTime / fadeTime));
			rend.material.color = color;
			yield return null;
		}
		yield return new WaitForSeconds (flashInterval);
		StartCoroutine (MakeVisible ()); 
		yield return null;
	}
}
