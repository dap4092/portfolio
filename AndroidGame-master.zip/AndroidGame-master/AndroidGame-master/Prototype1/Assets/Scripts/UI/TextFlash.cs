﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextFlash : MonoBehaviour {

    float elapsedTime;
    float startTime;
    float fadeTime = 1;
    float flashInterval = 0.25f; 
    CanvasGroup panel;

    bool startFade = false; 

	// Use this for initialization
	void Start () {
        panel = GetComponent<CanvasGroup>();
        StartCoroutine(Flash());
	}

    public void StartFadeOut()
    {
        //StopCoroutine(Flash());
        //StartCoroutine(FadeOut());
        startFade = true; 
    }

    IEnumerator Flash()
    {
        while (!startFade)
        {
            float elapsedTime = 0.0f;
            startTime = Time.time;

            while (panel.alpha > 0)
            {
                elapsedTime += Time.time - startTime;
                panel.alpha = Mathf.Clamp01(1.0f - (elapsedTime / fadeTime));
                yield return null;
            }
            yield return new WaitForSeconds(flashInterval);
            elapsedTime = 0.0f;
            startTime = Time.time;

            while (panel.alpha < 1)
            {
                elapsedTime += Time.time - startTime;
                panel.alpha = Mathf.Clamp01((elapsedTime / fadeTime));
                yield return null;
            }
            yield return new WaitForSeconds(flashInterval);
        }
        StartCoroutine(FadeOut());
        yield return null; 
    }

    IEnumerator FadeOut()
    {
        float elapsedTime = 0.0f;
        float start = Time.time;

        while (panel.alpha > 0)
        {
            elapsedTime += Time.time - startTime;
            panel.alpha = Mathf.Clamp01(1.0f - (elapsedTime / fadeTime));
            yield return null;
        }

        gameObject.SetActive(false);
        yield return null; 
    }
}
