﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; 

public class UIManager : MonoBehaviour {
	public float fadeTime; 

	CanvasGroup scoreCounter;
	CanvasGroup gameOverPanel;
    CanvasGroup tapText;
    TextFlash tapTextFlasher; 
	bool fading = false; 
	bool menuOpen = false; 
	float startTime;

	// Use this for initialization
	void Start () {
		scoreCounter = transform.GetChild(0).GetComponent<CanvasGroup>(); 
		gameOverPanel = transform.GetChild (1).GetComponent<CanvasGroup>();
        tapText = transform.GetChild(2).GetComponent <CanvasGroup > ();
        tapTextFlasher = tapText.gameObject.GetComponent<TextFlash>();
    }

    private void OnEnable()
    {
        GameManager.OnGameOver += ToggleGameOverMenu;
        GameManager.OnGameStart += ToggleTapText; 
    }

    private void OnDisable()
    {
        GameManager.OnGameOver -= ToggleGameOverMenu;
        GameManager.OnGameStart -= ToggleTapText;
    }

    void ToggleTapText()
    {
        scoreCounter.gameObject.SetActive(true);
        tapTextFlasher.StartFadeOut(); 
    }

    void ToggleGameOverMenu()
    {
        if (!fading)
        {
            if (menuOpen)
            {
                StartCoroutine(FadeMenuOut());
            }
            else
            {
                StartCoroutine(FadeMenuIn());
            }
        }
    }

	// Fades menu out based on fade time
	IEnumerator FadeMenuOut()
	{
		fading = true;
        scoreCounter.gameObject.SetActive(true);

        float elapsedTime = 0.0f;
        startTime = Time.time;

        while (gameOverPanel.alpha > 0 && scoreCounter.alpha < 1)
		{
			elapsedTime += Time.time - startTime;
			gameOverPanel.alpha = Mathf.Clamp01(1.0f - (elapsedTime / fadeTime));
            scoreCounter.alpha = Mathf.Clamp01((elapsedTime / fadeTime));
            yield return null;
		}

		yield return null;

		fading = false;
		menuOpen = false; 
		gameOverPanel.gameObject.SetActive(false);
	}

	// Fade menu in based on fade time
	IEnumerator FadeMenuIn()
	{
		fading = true;
		gameOverPanel.gameObject.SetActive(true);

        float elapsedTime = 0.0f;
        startTime = Time.time;

        while (gameOverPanel.alpha < 1 && scoreCounter.alpha > 0)
		{
			elapsedTime += Time.time - startTime;
			gameOverPanel.alpha = Mathf.Clamp01((elapsedTime / fadeTime));
            scoreCounter.alpha = Mathf.Clamp01(1.0f - (elapsedTime / fadeTime));
            yield return null;
		}

		yield return null;

		fading = false;   
		menuOpen = true;
        scoreCounter.gameObject.SetActive(false);
	}
}
