﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOverPanelScript : MonoBehaviour {

    Text currScoreText;
    Text bestScoreText;
    Button retryButton;
    Button shareButton; 

	// Use this for initialization
	void Start () {
        currScoreText = transform.GetChild(1).GetChild(0).GetComponent<Text>();
        bestScoreText = transform.GetChild(1).GetChild(1).GetComponent<Text>();
        retryButton = transform.GetChild(2).GetComponent<Button>(); 
        shareButton = transform.GetChild(3).GetComponent<Button>();

        retryButton.onClick.AddListener(() => RetryButtonFunc());
        shareButton.onClick.AddListener(() => ShareButtonFunc());

    }

    // Update is called once per frame
    void Update () {
        if (gameObject.activeSelf)
        {
            currScoreText.text = "Score: " + GameManager.Instance.currentScore;
            bestScoreText.text = "Best Score: " + GameManager.Instance.GetHighScore(); 
        }
    }

    void RetryButtonFunc()
    {
        // Reset Game State
        GameManager.Instance.currentScore = 0;
        GameManager.Instance.gameOver = false;
		GameManager.Instance.gameStarted = false; 
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    void ShareButtonFunc()
    {

    }
}
