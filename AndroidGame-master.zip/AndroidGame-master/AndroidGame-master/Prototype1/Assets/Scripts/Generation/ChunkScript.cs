﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkScript : MonoBehaviour {

    // Required for correct Generation 
    public ChunkGenerator generator;

    [HideInInspector]
    public float speed; // 0.1f; 
	public float id;

    private Transform parentContainer; 
    private bool triggered = false;


    private void Start()
    {
        parentContainer = transform.parent;
		id = GameManager.Instance.chunkNum;
    }


    private void Update()
    {
        parentContainer.Translate(new Vector3(0, 0, -speed));
    }

    void OnTriggerExit(Collider other)
    {
//		if(!triggered)
//        {
//            generator.GenerateChunk();
//            triggered = true; 
//        }

		if(!triggered)
		{
			generator.GenerateChunk();
			//generator.GenerateChunk();
			triggered = true; 
		}
    }

    private void OnEnable()
    {
        //generator.chunks.Add(transform.parent.gameObject);
    }

    private void OnDisable()
    {
        triggered = false; 
        //generator.chunks.Remove(transform.parent.gameObject);
        //Debug.Log(generator.chunks.Count);
    }

    // Setter 
    public void SetGenerator(ChunkGenerator gen)
    {
        generator = gen;
    }

}
