﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ScoreTriggerScript : MonoBehaviour {

    bool triggered = false;

    private void OnTriggerExit(Collider other)
    {
		if (triggered) {
			return;
		} else {
			if (!GameManager.Instance.gameOver) 
			{
				GameManager.Instance.currentScore += 1;
			}
            triggered = true;
        }
    }

    private void OnEnable()
    {
        triggered = false; 
    }
}
