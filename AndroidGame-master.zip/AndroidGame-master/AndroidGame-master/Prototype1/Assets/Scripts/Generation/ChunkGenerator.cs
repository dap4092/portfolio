﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChunkGenerator : MonoBehaviour {

    //public GameObject chunkPrefab;

    public List<GameObject> EasyChunkPrefabs;
    public List<GameObject> MediumChunkPrefabs;
    public List<GameObject> HardChunkPrefabs;
    public GameObject startChunk;
    public float chunkOffset;
    public float chunkSpeed;
	public int chunkIndex = 0;


    // private lists
	private List<GameObject> EasyChunks = new List<GameObject>(); 
	private List<GameObject> MediumChunks = new List<GameObject>();
	private List<GameObject> HardChunks = new List<GameObject>();


    // The current active chunks
    //[HideInInspector]
    public List<GameObject> chunks = new List<GameObject>();

    private GameObject instantiationPoint; 

	// Use this for initialization
	void Start () {

        // Create Generation Point. 
        instantiationPoint = new GameObject("Generation Point");
        //GameObject obj = Instantiate(instantiationPoint);
        instantiationPoint.transform.parent = transform;
        instantiationPoint.transform.position = new Vector3(1000, -1000, 0);

		for (int i = 0; i < 3; i++)
		{
	        // Initialize all chunks with generator specific attributes 
	        foreach (GameObject chunkPrefab in EasyChunkPrefabs)
	        {
	            GameObject go = Instantiate(chunkPrefab, instantiationPoint.transform.position, Quaternion.identity);
				go.GetComponentInChildren<ChunkScript>().SetGenerator(this);
				go.GetComponentInChildren<ChunkScript>().speed = chunkSpeed;
	            go.transform.parent = instantiationPoint.transform;
	            EasyChunks.Add(go);
	            go.SetActive(false);
	            
	        }
		}

        foreach (GameObject chunkPrefab in MediumChunkPrefabs)
        {
            GameObject go = Instantiate(chunkPrefab, instantiationPoint.transform.position, Quaternion.identity);
			go.GetComponentInChildren<ChunkScript>().SetGenerator(this);
			go.GetComponentInChildren<ChunkScript>().speed = chunkSpeed;
            go.transform.parent = instantiationPoint.transform;
			MediumChunks.Add(go);
            go.SetActive(false);
            
        }

        foreach (GameObject chunkPrefab in HardChunkPrefabs)
        {
            GameObject go = Instantiate(chunkPrefab, instantiationPoint.transform.position, Quaternion.identity);
			go.GetComponentInChildren<ChunkScript>().SetGenerator(this);
			go.GetComponentInChildren<ChunkScript>().speed = chunkSpeed;
            go.transform.parent = instantiationPoint.transform;
			HardChunks.Add(go);
            go.SetActive(false);
            
        }

        chunks.Clear();

        //GameObject startObj = startChunk.GetComponentInChildren<ChunkScript>().gameObject;
        startChunk.GetComponentInChildren<ChunkScript>().speed = 0;
        chunks.Add(startChunk);
    }

    private void Update()
    {
        if(GameManager.Instance.gameStarted)
        {
            startChunk.GetComponentInChildren<ChunkScript>().speed = Mathf.Lerp(0, chunkSpeed, Time.deltaTime * 25);
        }

        if(GameManager.Instance.gameOver)
        {
            foreach(GameObject chunk in chunks)
            {
                chunk.GetComponentInChildren<ChunkScript>().speed = Mathf.Lerp(chunkSpeed, 0, Time.deltaTime * 25);
            }
        }
    }

    public void GenerateChunk()
    {
		GameManager.Instance.chunkNum++;
        // Get a chunk from object pool. Account for difficulty
        GameObject chunk = null;
		//chunk = EasyChunks[chunkIndex];
        if (GameManager.Instance.currentScore < GameManager.Instance.easyThreshold)
        {
			chunk = EasyChunks[chunkIndex];
        }
		else if (GameManager.Instance.currentScore < GameManager.Instance.hardThreshold)
        {
			//chunkIndex = 0;
			chunk = MediumChunks[chunkIndex];
        }
        else if (GameManager.Instance.currentScore >= GameManager.Instance.hardThreshold)
        {
			chunk = HardChunks[chunkIndex];
        }
        
        // Enable chunk
		chunk.SetActive(true);

		Vector3 chunkPos;
		chunkPos = chunks[chunks.Count - 1].transform.position;


		// Get the floor tile which is currently scaled, offset by that amount 
		Transform p = chunk.transform;
		float depth = p.GetChild(0).transform.localScale.z;
//		Debug.Log("Child name: " + p.GetChild(0).name + " depth: " + depth);

		Vector3 pos = new Vector3(chunkPos.x, chunkPos.y, chunkPos.z);

		pos.z += depth + chunkOffset;

		chunk.transform.position = pos;

		chunks.Add (chunk);

		if(chunks.Count > 2)
		{
			chunks[0].SetActive(false);
			chunks.Remove (chunks [0]);
			//DestroyObject(chunks[0]);
		}

		chunkIndex++;


		// Shuffle Chunks 
		if (GameManager.Instance.currentScore < GameManager.Instance.easyThreshold)
		{
			if (chunkIndex > EasyChunks.Count - 1)
			{
				chunkIndex = 0;

				// shuffle the Easy Chunks to get another random order
				for (int i = 0; i < EasyChunks.Count - 2; i++)
				{
					int j = Random.Range(0, i + 1);
					GameObject firstItem = EasyChunks[j];
					GameObject secondItem = EasyChunks[i];
					EasyChunks[j] = secondItem;
					EasyChunks[i] = firstItem;
				}

				for (int i = 0; i < EasyChunks.Count; i++)
				{
					if (EasyChunks[i].activeSelf == false)
					{
						GameObject first = EasyChunks[i];
						GameObject second = EasyChunks[0];
						EasyChunks[0] = first;
						EasyChunks[i] = second;
					}
				}
			}
		}
		else if (GameManager.Instance.currentScore < GameManager.Instance.hardThreshold)
		{
			if (chunkIndex > MediumChunks.Count - 1)
			{
				chunkIndex = 0;

				// shuffle the Easy Chunks to get another random order
				for (int i = 0; i < MediumChunks.Count - 2; i++)
				{
					int j = Random.Range(0, i + 1);
					GameObject firstItem = MediumChunks[j];
					GameObject secondItem = MediumChunks[i];
					MediumChunks[j] = secondItem;
					MediumChunks[i] = firstItem;
				}

				for (int i = 0; i < MediumChunks.Count; i++)
				{
					if (MediumChunks[i].activeSelf == false)
					{
						GameObject first = MediumChunks[i];
						GameObject second = MediumChunks[0];
						MediumChunks[0] = first;
						MediumChunks[i] = second;
					}
				}
			}
		}
		else if (GameManager.Instance.currentScore >= GameManager.Instance.hardThreshold)
		{
			if (chunkIndex > HardChunks.Count - 1)
			{
				chunkIndex = 0;

				// shuffle the Easy Chunks to get another random order
				for (int i = 0; i < HardChunks.Count - 2; i++)
				{
					int j = Random.Range(0, i + 1);
					GameObject firstItem = HardChunks[j];
					GameObject secondItem = HardChunks[i];
					HardChunks[j] = secondItem;
					HardChunks[i] = firstItem;
				}

				for (int i = 0; i < HardChunks.Count; i++)
				{
					if (HardChunks[i].activeSelf == false)
					{
						GameObject first = HardChunks[i];
						GameObject second = HardChunks[0];
						HardChunks[0] = first;
						HardChunks[i] = second;
					}
				}
			}
		}


    }
}
