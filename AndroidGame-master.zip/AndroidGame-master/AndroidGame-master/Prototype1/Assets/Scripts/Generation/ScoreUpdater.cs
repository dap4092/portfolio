﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreUpdater : MonoBehaviour {

    Text textComp; 

    private void Start()
    {
        textComp = GetComponent<Text>(); 
    }

    private void OnEnable()
    {
        GameManager.OnScore += UpdateUI; 
    }

    private void OnDisable()
    {
        GameManager.OnScore -= UpdateUI;
    }

    void UpdateUI()
    {
        textComp.text = "Score: " + GameManager.Instance.currentScore; 
    }
}
