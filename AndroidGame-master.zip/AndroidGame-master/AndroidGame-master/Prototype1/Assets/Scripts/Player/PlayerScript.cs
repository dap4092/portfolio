﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour {

    public Material[] materials;

    private int materialIndex = 0; 
    //private Rigidbody body;
    private Collider box; 
    private Renderer rend;

	public AnimationCurve curve; 

    public float maxSpeed;
    public float laneOffset; //7.5f

    // Trajectory 
    Vector3 startPos;
    Vector3 endPos;
    float trajectoryHeight = 5;
    float startTimeTrajectory;

    // Lane Calculations
    int targetLane = 0; 
    int currentLane = 0;
    int minLaneIndex = -1;
    int maxLaneIndex = 1; 

    private bool shouldFlip = false;

    float startTimeSnap;
    private bool snapStarted = false;
    private Vector3 snapVec = Vector3.zero;

    // Swipe Vectors
    Vector2 firstPressPos;
    Vector2 secondPressPos;
    Vector2 currentSwipe;
    float swipeThreshold = .75f;

    // Audio 
    public AudioClip jumpSound;
    public AudioClip dieSound;
    public AudioClip collectSound;

    AudioSource source; 

    // Use this for initialization
    void Start () {
        rend = GetComponent<Renderer>();
        box = GetComponent<Collider>();
        source = GetComponent<AudioSource>();
        source.clip = jumpSound; 
		// Set Frame Rate 
		QualitySettings.vSyncCount = 0;
		Application.targetFrameRate = 30;
    }

    // Update is called once per frame -- Physics
    void FixedUpdate()
    {
        if (!GameManager.Instance.gameStarted || transform.position.y < -1)
        {
            return;
        }
        else
        {

            if (Application.isMobilePlatform)
            {
                MobileUpdate();
            }
            else
            {
                MouseUpdate();
            }

            if (!GameManager.Instance.gameOver)
            {
                if (shouldFlip)
                {
                    SnapAngle();
                    FlipCube();
                }
            }
        }

    }

    void MouseUpdate()
    {
        if (Input.GetMouseButtonDown(0))
        {
            //save began touch 2d point
            firstPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
        }
        if (Input.GetMouseButtonUp(0))
        {
            //save ended touch 2d point
            secondPressPos = new Vector2(Input.mousePosition.x, Input.mousePosition.y);

            //create vector from the two points
            currentSwipe = new Vector2(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

            //normalize the 2d vector
            currentSwipe.Normalize();

            if (!shouldFlip)
            {
                //swipe upwards
                if (currentSwipe.y > 0 && currentSwipe.x > -swipeThreshold && currentSwipe.x < swipeThreshold)
                {
                    //Debug.Log("up swipe");
                    targetLane = currentLane;
                    CalcTrajectory();
                    //shouldFlip = true;
                }
                //swipe down
                if (currentSwipe.y < 0 && currentSwipe.x > -swipeThreshold && currentSwipe.x < swipeThreshold)
                {
                    //Debug.Log("down swipe");
                }
                //swipe left
                if (currentSwipe.x < 0 && currentSwipe.y > -swipeThreshold && currentSwipe.y < swipeThreshold)
                {
                    //Debug.Log("left swipe");
                    targetLane = currentLane - 1;
                    CalcTrajectory();
                    //shouldFlip = true;
                }
                //swipe right
                if (currentSwipe.x > 0 && currentSwipe.y > -swipeThreshold && currentSwipe.y < swipeThreshold)
                {
                    //Debug.Log("right swipe");
                    targetLane = currentLane + 1;
                    CalcTrajectory();
                    //shouldFlip = true;
                }
            }
        }
    }

    void MobileUpdate()
    {
        if (Input.touches.Length > 0)
        {
            Touch t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Began)
            {
                //save began touch 2d point
                firstPressPos = new Vector2(t.position.x, t.position.y);
            }
            if (t.phase == TouchPhase.Ended)
            {
                //save ended touch 2d point
                secondPressPos = new Vector2(t.position.x, t.position.y);

                //create vector from the two points
                currentSwipe = new Vector3(secondPressPos.x - firstPressPos.x, secondPressPos.y - firstPressPos.y);

                //normalize the 2d vector
                currentSwipe.Normalize();

                //swipe upwards
                if (!shouldFlip)
                {
                    if (currentSwipe.y > 0 && currentSwipe.x > -swipeThreshold && currentSwipe.x < swipeThreshold)
                    {
                        //Debug.Log("up swipe");
                        targetLane = currentLane;
                        CalcTrajectory();
                        //shouldFlip = true;
                    }
                    //swipe down
                    if (currentSwipe.y < 0 && currentSwipe.x > -swipeThreshold && currentSwipe.x < swipeThreshold)
                    {
                        //Debug.Log("down swipe");
                    }
                    //swipe left
                    if (currentSwipe.x < 0 && currentSwipe.y > -swipeThreshold && currentSwipe.y < swipeThreshold)
                    {
                        //Debug.Log("left swipe");
                        targetLane = currentLane - 1;
                        CalcTrajectory();
                        //shouldFlip = true;
                    }
                    //swipe right
                    if (currentSwipe.x > 0 && currentSwipe.y > -swipeThreshold && currentSwipe.y < swipeThreshold)
                    {
                        targetLane = currentLane + 1;
                        CalcTrajectory();
                        //shouldFlip = true;
                        //Debug.Log("right swipe");
                    }
                }
            }
        }
    }

    void SnapAngle()
    {
        if(!snapStarted)
        {
            startTimeSnap = Time.time; 
            snapVec = transform.eulerAngles;

            if (targetLane < currentLane)
            {
                snapVec.z = Mathf.Round(snapVec.z / 90) + 90;
            }
            else if (targetLane > currentLane)
            {
                snapVec.z = Mathf.Round(snapVec.z / 90) - 90;
            }
            else
            {
                snapVec.x = Mathf.Round(snapVec.x / 90) + 90;
            }
            // Audio
            source.clip = jumpSound;
            source.Play();
        }
        float cTime = Mathf.Abs((startTimeSnap - Time.time));

        if (targetLane == currentLane)
        {
            float x = Mathf.LerpAngle(0, snapVec.x, cTime);
            x = Mathf.Round(x);
            transform.eulerAngles = new Vector3(x, 0, 0);
        }
        else {
            float z = Mathf.LerpAngle(0, snapVec.z, cTime);
            z = Mathf.Round(z);
            transform.eulerAngles = new Vector3(0, 0, z);
        }
        


        snapStarted = true; 
    }

    void CalcTrajectory()
    {
        // Make sure target lane is in bounds and then return
        if(targetLane < minLaneIndex)
        {
            targetLane = minLaneIndex;
            return; 
        }
        else if(targetLane > maxLaneIndex)
        {
            targetLane = maxLaneIndex;
            return; 
        }

        startTimeTrajectory = Time.time;
        startPos = new Vector3(transform.position.x, transform.position.y, transform.position.z);
        endPos = new Vector3(transform.position.x, transform.position.y, transform.position.z);

        if(targetLane < currentLane)
        {
            endPos.x -= laneOffset;
        }
        else if(targetLane > currentLane)
        {
            endPos.x += laneOffset;
        }
        else
        {
            endPos.y -= 0.1f;
        }
        shouldFlip = true; 
    }

    private void FlipCube()
    {
        // Calc time in Lerping Range
        //float cTime = Time.time * 0.2f;
        float cTime = Mathf.Abs((startTimeTrajectory - Time.time));
        //Debug.Log(cTime);


        // calculate straight-line lerp position:
        //Vector3 currentPos = Vector3.Lerp(startPos, endPos, cTime);
		Vector3 currentPos = Vector3.Lerp(startPos, endPos, curve.Evaluate(cTime));

        // add a value to Y, using Sine to give a curved trajectory in the Y direction
        currentPos.y += trajectoryHeight * Mathf.Sin(Mathf.Clamp01(cTime) * Mathf.PI);
        // finally assign the computed position to our gameObject:
        transform.position = currentPos;

        if (Vector3.Distance(transform.position, endPos) <= 0.01f)
        {
            // Reset and update lane counters
            shouldFlip = false;
            snapStarted = false;
            currentLane = targetLane;
        }
    }

    void SwitchMaterial()
    {
        if(materialIndex >= materials.Length - 1)
        {
            materialIndex = 0; 
        }
        else
        {
            materialIndex++; 
        }
        rend.material = materials[materialIndex];
    }

    private void OnTriggerEnter(Collider other)
    {
		if (other.gameObject.tag == "Collectible") {
			// Set player's color to coin's color
			Color match = other.GetComponent<Renderer>().material.color;
            //for (int i = 0; i < materials.Length - 1; i++) {
            //	if (materials [i].color == match) {
            //		materialIndex = i; 
            //		break; 
            //	}
            //}
            //rend.material = materials [materialIndex];
            rend.material.color = match;
            source.clip = collectSound;
            source.Play(); 
		}
        else
        {
            // Player is colliding with an obstacle and should end the game 
            Renderer colRend = other.gameObject.GetComponent<Renderer>();
            if (colRend == null)
            {
                // Collided object has no renderer so ignore. Examples would be score and generation triggers 
                return;
            }
            Color colorA = new Color(colRend.material.color.r, colRend.material.color.g, colRend.material.color.b, 1);
            Color colorB = new Color(rend.material.color.r, rend.material.color.g, rend.material.color.b, 1);

            if (!(colorA == colorB))
            {
                //Vector3 stopForce = body.velocity * 2;
                //stopForce *= -1;
                //stopForce.y *= maxSpeedY;
                //stopForce.z *= maxSpeedZ;

                GameManager.Instance.gameOver = true;
                source.clip = dieSound;
                source.Play();
                //Debug.Log("Game Over!");
            }
        }

//        Renderer colRend = other.gameObject.GetComponent<Renderer>();
//        if(colRend == null)
//        {
//            return;
//        }
//        if (!(colRend.material.color == rend.material.color))
//        {
//            //Vector3 stopForce = body.velocity;
//            //stopForce *= -1;
//            //stopForce.y *= maxSpeedY;
//            //stopForce.z *= maxSpeedZ; 
//            //body.velocity = Vector3.zero; 
//            //body.AddForce(stopForce);
//            //gameOver = true;
//            //Debug.Log("Game Over!");
//        }
    }

}
