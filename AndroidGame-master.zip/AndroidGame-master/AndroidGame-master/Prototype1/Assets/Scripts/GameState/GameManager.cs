﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameManager : Singleton<GameManager>
{
    protected GameManager() { } // guarantee this will be always a singleton only - can't use the constructor!

    // State 
    public int currentScore;
    private int prevScore;
    public bool gameStarted = false;
    public bool gameOver = false;
    private bool prevState; 
	public int chunkNum = 0;

    // Difficulty
    public int easyThreshold = 9;
    public int hardThreshold = 75;

    // Events
    public delegate void ScoreAction();
    public static event ScoreAction OnScore;

	public delegate void GameOverAction (); 
	public static event GameOverAction OnGameOver;

    public delegate void GameStartAction();
    public static event GameStartAction OnGameStart;

    private void FixedUpdate()
    {
        if (gameStarted)
        {
            if (gameOver)
            {
                StoreHighScore(); 
                if (OnGameOver != null && gameOver != prevState)
                {
                    // Updates and displays UI
                    OnGameOver();
                }
                prevScore = 0; 
            }
            else
            {
                if (currentScore != prevScore)
                {
                    if (OnScore != null)
                        OnScore();
                }
            }
            prevScore = currentScore;
            prevState = gameOver;
        }
        else
        {
            if (OnGameStart != null)
            {
                if (Application.isMobilePlatform)
                {
                    if (Input.touchCount > 0)
                    {
                        OnGameStart();
                        gameStarted = true;
                    }
                }
                else if (Input.GetMouseButtonDown(0))
                {
                    OnGameStart();
                    gameStarted = true;
                }
            }
        }
    }

    private void StoreHighScore()
    {
        int oldHighscore = PlayerPrefs.GetInt("highscore", 0);
        if (currentScore > oldHighscore)
            PlayerPrefs.SetInt("highscore", currentScore);
    }

    public int GetHighScore()
    {
        return PlayerPrefs.GetInt("highscore", 0);
    }
}
